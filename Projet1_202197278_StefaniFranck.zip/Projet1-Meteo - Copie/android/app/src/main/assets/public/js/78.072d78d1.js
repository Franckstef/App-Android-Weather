"use strict";(self["webpackChunkProjet1_Meteo"]=self["webpackChunkProjet1_Meteo"]||[]).push([[78],{78:function(e,t,n){n.r(t),n.d(t,{startStatusTap:function(){return s}});var o=n(65),r=n(587);
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
const s=()=>{const e=window;e.addEventListener("statusTap",(()=>{(0,o.wj)((()=>{const t=e.innerWidth,n=e.innerHeight,s=document.elementFromPoint(t/2,n/2);if(!s)return;const c=s.closest("ion-content");c&&new Promise((e=>(0,r.c)(c,e))).then((()=>{(0,o.Iu)((async()=>{c.style.setProperty("--overflow","hidden"),await c.scrollToTop(300),c.style.removeProperty("--overflow")}))}))}))}))}}}]);
//# sourceMappingURL=78.072d78d1.js.map